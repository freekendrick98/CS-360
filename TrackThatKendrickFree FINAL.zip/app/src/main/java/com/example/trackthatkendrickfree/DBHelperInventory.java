package com.example.trackthatkendrickfree;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
//DB for inventory management
public class DBHelperInventory extends SQLiteOpenHelper {
    public DBHelperInventory(Context context) {
        super(context, "UserData.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB)
    {
        DB.execSQL("create Table Userdetails(C1 TEXT, C2 TEXT, C3 TEXT, C4, C5, C6, C7, C8, C9, C10, C11, C12, C13, C14, C15, C16, C17, C18, C19, C20, C21, C22, C1x, C2x, C3x, C4x)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1)
    {
        DB.execSQL("drop Table if exists UserDetails");
    }

    //declare each piece of data to be used in the DB (a lot of inventory slots).
    public Boolean insertUserData(String C1, String C2, String C3, String C4, String C5, String C6, String C7, String C8, String C9, String C10, String C11, String C12, String C13,
                                  String C14, String C15, String C16, String C17, String C18, String C19, String C20, String C21, String C22, String C1x, String C2x, String C3x, String C4x)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("C1", C1);
        contentValues.put("C2", C2);
        contentValues.put("C3", C3);
        contentValues.put("C4", C4);
        contentValues.put("C5", C5);
        contentValues.put("C6", C6);
        contentValues.put("C7", C7);
        contentValues.put("C8", C8);
        contentValues.put("C9", C9);
        contentValues.put("C10", C10);
        contentValues.put("C11", C11);
        contentValues.put("C12", C12);
        contentValues.put("C13", C13);
        contentValues.put("C14", C14);
        contentValues.put("C15", C15);
        contentValues.put("C16", C16);
        contentValues.put("C17", C17);
        contentValues.put("C18", C18);
        contentValues.put("C19", C19);
        contentValues.put("C20", C20);
        contentValues.put("C21", C21);
        contentValues.put("C22", C22);
        contentValues.put("C1x", C1x);
        contentValues.put("C2x", C2x);
        contentValues.put("C3x", C3x);
        contentValues.put("C4x", C4x);
        long resutls = DB.insert("userdetails", null, contentValues);
        if(resutls==1)
        {
            return false;
        }
        else
        {
            return true;
        }

    }

    public Boolean updateUserData(String C1, String C2, String C3, String C4, String C5, String C6, String C7, String C8, String C9, String C10, String C11, String C12, String C13,
                                  String C14, String C15, String C16, String C17, String C18, String C19, String C20, String C21, String C22, String C23, String C24, String C25)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("C1", C1);
        contentValues.put("C2", C2);
        contentValues.put("C3", C3);
        contentValues.put("C4", C4);
        contentValues.put("C5", C5);
        contentValues.put("C6", C6);
        contentValues.put("C7", C7);
        contentValues.put("C8", C8);
        contentValues.put("C9", C9);
        contentValues.put("C10", C10);
        contentValues.put("C11", C11);
        contentValues.put("C12", C12);
        contentValues.put("C13", C13);
        contentValues.put("C14", C14);
        contentValues.put("C15", C15);
        contentValues.put("C16", C16);
        contentValues.put("C17", C17);
        contentValues.put("C18", C18);
        contentValues.put("C19", C19);
        contentValues.put("C20", C20);
        contentValues.put("C21", C21);
        contentValues.put("C22", C22);
       //contentValues.put("C1x", C1x);//For some reason I cannot update these pieces of data. Android Studio throws an error.
       // contentValues.put("C2x", C2x);
       // contentValues.put("C3x", C3x);
        //contentValues.put("C4x", C4x);
        //long resutls = DB.update();
        //if(resutls==1)
        {
            //return false;
        }
       // else
        {
          //  return true;
        }

        return null;
    }


}
