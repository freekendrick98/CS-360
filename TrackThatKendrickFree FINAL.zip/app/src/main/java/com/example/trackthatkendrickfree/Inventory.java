package com.example.trackthatkendrickfree;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
//Originally the grid could be edited by
public class Inventory extends AppCompatActivity {
    //Declare all variables to be used for buttons and EditText
    EditText C1;
    EditText C2;
    EditText C3;
    EditText C4;
    EditText C5;
    EditText C6;
    EditText C7;
    EditText C8;
    EditText C9;
    EditText C10;
    EditText C11;
    EditText C12;
    EditText C13;
    EditText C14x;//Android Studio Would not let me use C14 without throwing an error so I renamed it C14x
    EditText C15;
    EditText C16;
    EditText C17;
    EditText C18;
    EditText C19;
    EditText C20;
    EditText C21;
    EditText C22;
    EditText C1x;
    EditText C2x;
    EditText C3x;
    EditText C4x;
    Button add1;
    Button add2;
    Button add3;
    Button add4;
    Button add5;
    Button add6;
    Button add7;
    Button add8;
    Button add9;
    Button add10;
    Button add11;
    Button delete1;
    Button delete2;
    Button delete3;
    Button delete4;
    Button delete5;
    Button delete6;
    Button delete7;
    Button delete8;
    Button delete9;
    Button delete10;
    Button delete11;
    Button update1;
    Button update2;
    Button update3;
    Button update4;
    Button update5;
    Button update6;
    Button update7;
    Button update8;
    Button update9;
    Button update10;
    Button update11;

    String row1;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        //get all buttons and edittext from xml to edit the grid data.
        C1 = (EditText) findViewById(R.id.C1);
        C2 = (EditText) findViewById(R.id.C2);
        C3 = (EditText) findViewById(R.id.C3);
        C4 = (EditText) findViewById(R.id.C4);
        C5 = (EditText) findViewById(R.id.C5);
        C6 = (EditText) findViewById(R.id.C6);
        C7 = (EditText) findViewById(R.id.C7);
        C8 = (EditText) findViewById(R.id.C8);
        C9 = (EditText) findViewById(R.id.C9);
        C10  = (EditText) findViewById(R.id.C10);
        C11 = (EditText) findViewById(R.id.C11);
        C12 = (EditText) findViewById(R.id.C12);
        C13 = (EditText) findViewById(R.id.C13);
        C14x = (EditText) findViewById(R.id.C14x);
        C15 = (EditText) findViewById(R.id.C15);
        C16 = (EditText) findViewById(R.id.C16);
        C17 = (EditText) findViewById(R.id.C17);
        C18 = (EditText) findViewById(R.id.C18);
        C19 = (EditText) findViewById(R.id.C19);
        C20 = (EditText) findViewById(R.id.C20);
        C21 = (EditText) findViewById(R.id.C21);
        C22 = (EditText) findViewById(R.id.C22);
        C1x = (EditText) findViewById(R.id.C1x);
        C2x = (EditText) findViewById(R.id.C2x);
        C3x = (EditText) findViewById(R.id.C3x);
        C4x = (EditText) findViewById(R.id.C4x);
        add1 = (Button) findViewById(R.id.add1);
        add2 = (Button) findViewById(R.id.add2);
        add3 = (Button) findViewById(R.id.add3);
        add4 = (Button) findViewById(R.id.add4);
        add5 = (Button) findViewById(R.id.add5);
        add6 = (Button) findViewById(R.id.add6);
        add7 = (Button) findViewById(R.id.add7);
        add8 = (Button) findViewById(R.id.add8);
        add9 = (Button) findViewById(R.id.add9);
        add10 = (Button) findViewById(R.id.add10);
        add11 = (Button) findViewById(R.id.add11);
        delete1 = (Button) findViewById(R.id.delete1);
        delete2 = (Button) findViewById(R.id.delete2);
        delete3 = (Button) findViewById(R.id.delete3);
        delete4 = (Button) findViewById(R.id.delete4);
        delete5 = (Button) findViewById(R.id.delete5);
        delete6 = (Button) findViewById(R.id.delete6);
        delete7 = (Button) findViewById(R.id.delete7);
        delete8 = (Button) findViewById(R.id.delete8);
        delete9 = (Button) findViewById(R.id.delete9);
        delete10 = (Button) findViewById(R.id.delete10);
        delete11 = (Button) findViewById(R.id.delete11);
        update1 = (Button) findViewById(R.id.update1);
        update2 = (Button) findViewById(R.id.update2);
        update3 = (Button) findViewById(R.id.update3);
        update4 = (Button) findViewById(R.id.update4);
        update5 = (Button) findViewById(R.id.update5);
        update6 = (Button) findViewById(R.id.update6);
        update7 = (Button) findViewById(R.id.update7);
        update8 = (Button) findViewById(R.id.update8);
        update9 = (Button) findViewById(R.id.update9);
        update10 = (Button) findViewById(R.id.update10);
        update11 = (Button) findViewById(R.id.update11);

    }

       //showtoast to show the user input for add button.
        private void showToast(String text)
        {
            Toast.makeText(Inventory.this, text, Toast.LENGTH_SHORT).show();
        }


    }
