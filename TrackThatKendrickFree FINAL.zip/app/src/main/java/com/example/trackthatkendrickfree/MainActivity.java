package com.example.trackthatkendrickfree;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //Text and buttons to be used in Login
    EditText username;
    EditText password;
    EditText repeatPassword;
    Button login;
    Button createAccount;
    DBHelper DB;
    TextView compName;
    TextView reminder;
    ImageView leftarrow;
    ImageView inventoryPic;

    //Variables for login verification
    //use these variables to login

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        repeatPassword = (EditText) findViewById(R.id.repeatPassword);
        compName = (TextView) findViewById(R.id.companyName);
        reminder = (TextView) findViewById(R.id.reminder);
        login = (Button) findViewById(R.id.SignIn);
        createAccount = (Button) findViewById(R.id.CreateAccount);
        leftarrow = (ImageView) findViewById(R.id.leftarrow);
        inventoryPic = (ImageView) findViewById(R.id.inventoryPic);
        DB = new DBHelper(this);

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String repeatPass = repeatPassword.getText().toString();
                if(user.equals("")||pass.equals("")||repeatPass.equals(""))
                    Toast.makeText(MainActivity.this,"Enter all fields with desired information",Toast.LENGTH_SHORT).show();
                else {
                    if (pass.equals(repeatPass))//check if user exist or not
                    {
                        Boolean checkuser = DB.usernameVerification(user);
                        if (checkuser == false) {
                            Boolean insert = DB.insertData(user, pass);
                            if (insert = true) {
                                Toast.makeText(MainActivity.this, "Successful Registration!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), permission.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(MainActivity.this, "Unsuccessful Registration!", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(MainActivity.this, "This user already exist! Proceed to sign in.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else
                    {
                        Toast.makeText(MainActivity.this, "Passwords do not match!.", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });
        //proceed to login page
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            //open inventory when login button clicked
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),SignIn.class);
                startActivity(intent);


            }
        });

    }
}
