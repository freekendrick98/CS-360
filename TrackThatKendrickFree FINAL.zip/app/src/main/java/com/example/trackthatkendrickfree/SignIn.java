package com.example.trackthatkendrickfree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

//Access DBHelper class
public class SignIn extends AppCompatActivity {

    EditText username;
    EditText password;
    Button Signup;
    Button HomeScreen;
    TextView SignInWelcome;
    DBHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        username = (EditText) findViewById(R.id.username1);
        password = (EditText) findViewById(R.id.password1);
        HomeScreen = (Button) findViewById(R.id.HomeScreen);
        SignInWelcome = (TextView) findViewById(R.id.SignInWelcome);
        Signup = (Button) findViewById(R.id.SignIn1);
        DB = new DBHelper(this);

        HomeScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });

        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if(user.equals("")||pass.equals(""))
                    Toast.makeText(SignIn.this,"Please enter all information.", Toast.LENGTH_SHORT).show();
                else
                {
                    Boolean passwordVeification = DB.passwordVerification(user,pass);
                    if(passwordVeification==true)
                    {
                        Toast.makeText(SignIn.this,"Successful Sign in!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(),permission.class);
                        startActivity(intent);
                    }
                    else
                    {
                        Toast.makeText(SignIn.this,"Invalid Credentials!", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });
        {

        }

    }
}