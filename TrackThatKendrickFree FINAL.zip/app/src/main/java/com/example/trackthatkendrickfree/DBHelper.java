package com.example.trackthatkendrickfree;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


import androidx.annotation.Nullable;
//Construct Database
public class DBHelper extends SQLiteOpenHelper {

    public static final String DBNAME = "LoginCred.db";

    //Create LogDB database for login credentials
    public DBHelper(Context context) {
        super(context, "LoginCred.db", null, 1);
    }

    //create users and password
    @Override
    public void onCreate(SQLiteDatabase LogDB) {
        LogDB.execSQL("create Table users(username TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase LogDB, int i, int i1) {
        LogDB.execSQL("drop Table if exists users");


    }
//get user credentials for database
    public Boolean insertData(String username, String password)
    {
        SQLiteDatabase LogDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long results = LogDB.insert("users",null,contentValues);

        if(results==-1) return false;
        else
            return true;
    }
    //Check if user exist in table or not
    public Boolean usernameVerification(String username)
    {
        SQLiteDatabase LogDB = this.getWritableDatabase();
        Cursor cursor = LogDB.rawQuery("Select * from users where username = ?",new String[]{username});
        if(cursor.getCount()>0)
            return true;
        else
            return false;

    }
    //password verification
    public Boolean passwordVerification(String username, String password)
    {
        SQLiteDatabase LogDB = this.getWritableDatabase();
        Cursor cursor = LogDB.rawQuery("Select * from users where username = ? and password = ?", new String[] {username,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }


}
