package com.example.trackthatkendrickfree;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class permission extends AppCompatActivity {
    Button proceed;
    //used for SMS permissions
    private static final int REQUEST_SMS_PERMISSION = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        proceed = (Button)findViewById(R.id.proceed);
        //if permission is not active ask user if they want to enable permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED)
        {   //check to see if user denies permission
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS))
            {


            }
            else
            {
                //User prompt to allow or deny SMS services
                ActivityCompat.requestPermissions(this, new  String[]{Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);

            }

        }

        //proceed button for the SMS screen that appears every time the application is launched.
       proceed.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(getApplicationContext(),Inventory.class);
               startActivity(intent);
           }
       });

    }

    public void onRequestPermissionResult(int requestCode, String permissions[], int[] grantResults)
    {
        //check the request code
        switch (requestCode)
        {
            case REQUEST_SMS_PERMISSION:
            {
                //check if result is approval or denial
                if (grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    Toast.makeText(this, "SMS Permissions Granted!", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), Inventory.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(this, "SMS Permissions Rejected! App will function without SMS services.", Toast.LENGTH_LONG).show();
                }

            }
        }

    }


}